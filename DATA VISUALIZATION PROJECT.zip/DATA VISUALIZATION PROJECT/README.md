#DEADLIEST EARTQUAKES DATA VISUALIZATION


The program displays the data by with some text, but it mostly visualizes the fatalties (deathtoll) of the earthquakes by the use of ellipse shapes that i made dynamic. how big the ellipses are depend on the fatalties of the earthquake itself. The more death, the bigger the ellipses and the dynamic that follows trough. The earthquake that ever caused the most fataltie, is also the one with the biggest magnitude of 9.30. You can easily recover this in the program. It would be easy to declare that the highest the magnitude of the earthquake is, the more death it cause's, but by the level of stroke that i gave to the magnitude, you can see that sometimes some high level magnitude earthquake ( let's say around 8 ), can cause very few deaths. Indeed, by contemplating this data, we can figure out that the geographic position of an earthquake has way more impact on the deathtoll, than the magnitude. if a high impact eartquake happens, in the middle of the desert, very few death will occur, on the contrary;  in highly populated regions like china or indonesia, earthquakes may have a way bigger number of deaths. 

##challenges 
i've found it quite hard to access to one specific data (number or stats) and to then retrieve it and use it later in the class dataPoint. 

I've also challenged a lot with cvs files, it's not really my cup of tea and i've had to change dataset 2-3 times because I had problem with the files ( broken, chrome not accepting , too heavy etc..)

Since i had to navigate through the datasets problems, I lost a bit of time, but in overall im happy with the end result and my intentions 

#Iteration
I got inspiration by the piece 'hard data' by Luke Dubois and also by exploring pieces from artist Ryoji Ikeda. 
