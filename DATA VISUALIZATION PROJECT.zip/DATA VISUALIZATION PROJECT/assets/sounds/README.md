# Sounds folder

This is the folder where you would keep all the sound files associated with your project, such as `.mp3`, `.wav`, and other formats. An example sound, `bark.wav`, is here in case you need something to play around with.
